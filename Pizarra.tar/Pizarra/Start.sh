#! /bin/bash
cd "$(dirname "$0")"

while true ; do
	HDMI=$(xrandr -q | grep "HDMI-2 connected")
	if [ ! -z "$HDMI" ] ; then
		break
	fi
	sleep 30
done

python3 main.py &
sleep 2
xdotool mousemove 300 600 click 1
xprop -name 'tk' -f _NET_WM_STATE 32a -set _NET_WM_STATE _NET_WM_STATE_SKIP_TASKBAR
sleep 30
xprop -name 'tk' -f _NET_WM_STATE 32a -set _NET_WM_STATE _NET_WM_STATE_SKIP_TASKBAR
exit

